package com.example.dandee;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class OutdoorOptionActivity extends Activity {

	/** Called when the activity is first created. */
	@Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
         
        // ������ ��Ƽ��Ƽ�� �������ش�.
        setContentView(R.layout.activity_outdoor_option);
        
        Button carBtn = (Button) findViewById(R.id.carButton);
        Button loudButton = (Button) findViewById(R.id.loudButton);
        TextView title = (TextView) findViewById(R.id.titleText);
    }
 


}