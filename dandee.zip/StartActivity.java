package com.example.dandee;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ImageButton;
import android.content.Intent;

public class StartActivity extends Activity {
	
	ImageView image_logo;
	ImageButton btn_outdoor, btn_indoor; //button
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_start);
		btn_outdoor = (ImageButton)findViewById(R.id.btn_outdoor);
		btn_indoor = (ImageButton)findViewById(R.id.btn_indoor);
		
		btn_outdoor.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent outdoor_intent = new Intent(StartActivity.this, OutdoorActivity.class);
				startActivity(outdoor_intent);
			}
		});
	}
}
